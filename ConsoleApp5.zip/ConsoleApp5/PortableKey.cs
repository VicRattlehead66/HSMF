﻿using System;

// A Group key that can be passed to a separate method.  
// Override Equals and GetHashCode to define equality for the key.  
// Override ToString to provide a friendly name for Key.ToString()  
namespace dupfin
{
    class PortableKey
    {
        public string Name { get; set; }
        public DateTime CreationTime { get; set; }
        public long Length { get; set; }

        public override bool Equals(object obj)
        {
            PortableKey other = (PortableKey)obj;
            return other.CreationTime == CreationTime &&
                   other.Length == Length &&
                   other.Name == Name;
        }

        public override int GetHashCode()
        {
            string str = String.Format("{0}{1}{2}", CreationTime, Length, Name);
            return str.GetHashCode();
        }
        public override string ToString()
        {
            return String.Format("{0} {1} {2}", Name, Length, CreationTime);
        }
    }
}